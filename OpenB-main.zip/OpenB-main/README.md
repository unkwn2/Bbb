# Open BYD

[![Kotlin](https://img.shields.io/badge/Kotlin-1.9+-blue.svg)](https://kotlinlang.org)
[![Platform](https://img.shields.io/badge/Platform-Android%20Automotive-green.svg)](https://www.android.com/auto/)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Offline First](https://img.shields.io/badge/Offline-100%25-success.svg)](#security--privacy)

**Open BYD Assistant** is an open-source, multilingual, and 100% offline voice assistant and utility tool designed specifically for imported BYD vehicles.

Most imported BYD cars come with system software that lacks non-Chinese voice assistant support. While closed-source alternatives like *BYD Connect* exist (primarily in Russian) and depends on DiPlus app (which is designed for the Chinese market, includes extensive functionality, uses the same privilege escalation exploit, is closed-source and is exposed to the internet), **Open BYD Assistant** aims to provide a transparent, community-driven, and highly secure alternative with support for English, Spanish and other languages.

## 🎯 Objectives
1. **Multilingual Voice Control:** Execute simple vehicle commands (e.g., "open the windows", "turn on AC", "open Spotify") in your native language.
2. **Steering Wheel Remapping:** Intercept and map physical steering wheel buttons to custom actions or third-party apps.
3. **Total Privacy & Security:** Vehicle systems are highly sensitive. Because this app utilizes a privilege escalation exploit to control the car's hardware, it is built to operate **100% locally**. It requires no internet connection, ensuring malicious actors cannot remotely hijack MCU commands or telemetry.

> **🔒 Note on the INTERNET permission:**
> You will notice `android.permission.INTERNET` in the source code. Android requires this permission to create any socket connection, even local ones. We strictly use this permission to communicate with the car's local ADB daemon (`127.0.0.1:5555`). Open BYD Assistant has zero tracking, zero analytics, and does not make any external HTTP requests to the outside world.

## 🛠 Features (In Development)
-[x] Base architectural foundation & IPC setup.
- [ ] Privilege proxy injection via ADB.
- [ ] Custom Voice Wake-word detection (Offline PocketSphinx/Vosk).
- [x] Steering wheel button listener and remapper (via `SteeringWheelAccessibilityService`).
- [ ] Car Body integration (Windows, Doors, AC, Sunroof).
- [ ] Third-party app launcher.

---

## 🔬 How It Works (Technical Details)

Normal Android applications run inside a sandbox and cannot directly interact with a vehicle's low-level hardware or proprietary APIs (like `android.hardware.bydauto.*`). To bypass this, Open BYD Assistant uses a **Privilege Escalation Proxy** initiated via ADB.

### The ADB Exploit & `app_process`
To gain access to the system-level vehicle APIs, the application relies on ADB (Android Debug Bridge) to spawn a secondary Java process as the `shell` user (`UID 2000`).

1. **Proxy Injection:** The user connects to the car via ADB (either via USB or wireless ADB loopback) and executes a specific `app_process` shell command.
2. **Framework Hooking:** The shell command injects the car's internal `/system/framework/bmmcamera.jar` into the classpath. This bypasses the standard application sandbox and allows our code to call hidden BYD APIs.
3. **Binder IPC:** Once the background proxy is running with `UID 2000` privileges, it creates an AIDL (Android Interface Definition Language) Binder and broadcasts it back to our unprivileged UI application.
4. **Execution:** When you say "Open the windows", the UI sends an IPC message to the privileged proxy, which then calls the internal `BYDAutoBodyDevice` methods to roll down the windows.

---

## 🏗 Proposed Project Structure

To maintain clean architecture and separate the unprivileged UI from the privileged proxy, the project is structured as a **Multi-Module Kotlin Gradle Project**:

```text
Open-BYD-Assistant/
├── app/                      # Main Unprivileged App (UI, Voice, Accessibility)
│   ├── src/main/java/com/sr/openbyd/assistant/
│   │   ├── ui/               # Jetpack Compose UI (Settings, App Launcher)
│   │   ├── voice/            # Offline Voice Recognition (Vosk/Google Offline)
│   │   ├── service/          # AccessibilityService (Steering wheel remapping)
│   │   └── receiver/         # Broadcast receivers to catch the Proxy Binder
│   └── build.gradle.kts
│
├── proxy-server/             # Privileged Process Code (Compiled to a raw .dex)
│   ├── src/main/java/com/sr/openbyd/proxy/
│   │   ├── EntryPoint.kt     # main() function executed by ADB app_process
│   │   ├── CarControlImpl.kt # Implements AIDL interfaces using BYD APIs
│   │   └── hardware/         # Stub classes mapping to android.hardware.bydauto.*
│   └── build.gradle.kts
│
├── core-aidl/                # Shared IPC Interfaces
│   ├── src/main/aidl/com/sr/openbyd/ipc/
│   │   ├── ICarControl.aidl  # e.g., void openWindow(int doorId);
│   │   └── IProxyBinder.aidl # Used to establish the initial connection
│   └── build.gradle.kts
│
└── scripts/                  # Injection Shell scripts
    └── launch_proxy.sh       # ADB script to kill old proxy and start the new one
```

### Module Breakdown
* `:core-aidl` - Contains the interface definitions so both the App and the Proxy know how to talk to each other.
* `:proxy-server` - Lightweight, no-UI module. It is compiled into a standalone `.dex` file. This is the code that runs with elevated privileges.
* `:app` - The standard Android application installed on the car's head unit.

---

## 🚀 Getting Started


### Installation (Draft)
1. Install the `app-debug.apk` directly onto the car's head unit.
2. Connect to the car via ADB:
   ```bash
   adb connect <CAR_IP>:5555
   ```
3. Run the privilege injection script:
   ```bash
   adb shell sh /sdcard/Android/data/com.openbyd.assistant/files/launch_proxy.sh
   ```
4. Open the App on the head unit. The status should turn to **"Proxy Connected"**.

---

## 🤝 Contributing

Because we are dealing with vehicle controls, security and code transparency are our highest priorities.
* **Reverse Engineers:** Help us map the `android.hardware.bydauto.*` opcodes and functions.
* **Kotlin Developers:** Help build the Compose UI, Voice Assistant bindings, and general app architecture.
* **Translators:** Help translate the voice commands and UI into Spanish, English, and other languages.

Please read our [CONTRIBUTING.md](CONTRIBUTING.md) before submitting pull requests.

## 🛡 Disclaimer
**USE AT YOUR OWN RISK.** This software is provided "as is" without warranty of any kind. Interacting with internal vehicle APIs can result in unexpected behavior. The developers are not responsible for any damage to your vehicle, voided warranties, or safety incidents. Please ensure your car is parked in a safe environment when testing new features.

---
*Built with ❤️ by the BYD Open Source community.*